document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('#addRectangle').addEventListener('click', addRectangle);
    document.querySelector('#addCircle').addEventListener('click', addCircle);
});

function addRectangle() {
    const obj = createObject('rectangle');
    addObjectToCanvas(obj);
}

function addCircle() {
    const obj = createObject('circle');
    addObjectToCanvas(obj);
}

function createObject(type) {
    const name = document.getElementById('objectName').value || 'Objeto';
    const color = document.getElementById('colorPicker').value; // Obtém a cor selecionada
    const obj = document.createElement('div');
    obj.classList.add('draggable');
    obj.dataset.type = type;
    obj.dataset.name = name;
    obj.style.width = '100px';
    obj.style.height = '100px';
    obj.style.backgroundColor = color; // Aplica a cor selecionada
    if (type === 'circle') obj.style.borderRadius = '50%';
    return obj;
}

function addObjectToCanvas(obj) {
    const canvas = document.getElementById('designCanvas');
    const resizer = document.createElement('div');
    resizer.classList.add('resizer');
    obj.appendChild(resizer);
    canvas.appendChild(obj);
    makeDraggable(obj);
    updateCSS();
}

function makeDraggable(el) {
    const resizer = el.querySelector('.resizer');
    let originalWidth = 0, originalHeight = 0, originalMouseX = 0, originalMouseY = 0;
    let originalX = 0, originalY = 0;

    const dragStart = (e) => {
        if (e.target === resizer) {
            originalWidth = parseFloat(getComputedStyle(el, null).getPropertyValue('width').replace('px', ''));
            originalHeight = parseFloat(getComputedStyle(el, null).getPropertyValue('height').replace('px', ''));
            originalMouseX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
            originalMouseY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
            document.addEventListener('mousemove', resize);
            document.addEventListener('touchmove', resize, { passive: false });
            document.addEventListener('mouseup', stopResize);
            document.addEventListener('touchend', stopResize);
        } else {
            originalX = el.getBoundingClientRect().left;
            originalY = el.getBoundingClientRect().top;
            originalMouseX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
            originalMouseY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
            document.addEventListener('mousemove', dragMove);
            document.addEventListener('touchmove', dragMove, { passive: false });
            document.addEventListener('mouseup', dragEnd);
            document.addEventListener('touchend', dragEnd);
        }
    };

    const dragMove = (e) => {
        const currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        const currentY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
        const dx = currentX - originalMouseX;
        const dy = currentY - originalMouseY;
        el.style.left = originalX + dx + 'px';
        el.style.top = originalY + dy + 'px';
        updateCSS();
        e.preventDefault();
    };

    const resize = (e) => {
        const currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
        const currentY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
        const width = originalWidth + (currentX - originalMouseX);
        const height = originalHeight + (currentY - originalMouseY);
        el.style.width = `${width}px`;
        el.style.height = `${height}px`;
        updateCSS();
        e.preventDefault();
    };

    const stopResize = () => {
        document.removeEventListener('mousemove', resize);
        document.removeEventListener('touchmove', resize);
        document.removeEventListener('mouseup', stopResize);
        document.removeEventListener('touchend', stopResize);
    };

    const dragEnd = () => {
        document.removeEventListener('mousemove', dragMove);
        document.removeEventListener('touchmove', dragMove);
        document.removeEventListener('mouseup', dragEnd);
        document.removeEventListener('touchend', dragEnd);
    };

    el.addEventListener('mousedown', dragStart);
    el.addEventListener('touchstart', dragStart, { passive: false });
}

function updateCSS() {
    const cssCode = document.getElementById('cssCode');
    cssCode.textContent = '';
    document.querySelectorAll('#designCanvas .draggable').forEach(el => {
        const id = el.getAttribute('id') || Math.random().toString(36).substr(2, 9);
        el.setAttribute('id', id);
        const type = el.dataset.type=== 'rectangle' ? 'Retângulo' : 'Círculo';
        const name = el.dataset.name || 'Objeto';
        // Colocando o comentário com o nome do objeto acima do código CSS
        cssCode.textContent += `/* ${type}: ${name} */\n`;
        cssCode.textContent += `#${id} {\n`;
        cssCode.textContent += `    width: ${el.style.width};\n`;
        cssCode.textContent += `    height: ${el.style.height};\n`;
        cssCode.textContent += `    background-color: ${el.style.backgroundColor};\n`;
        cssCode.textContent += `    border-radius: ${el.style.borderRadius};\n`;
        cssCode.textContent += `    position: absolute;\n`;
        cssCode.textContent += `    left: ${el.style.left};\n`;
        cssCode.textContent += `    top: ${el.style.top};\n`;
        cssCode.textContent += `}\n\n`;
    });
}